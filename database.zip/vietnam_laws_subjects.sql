--
-- PostgreSQL database dump
--

-- Dumped from database version 14.10 (Debian 14.10-1.pgdg120+1)
-- Dumped by pg_dump version 14.9 (Ubuntu 14.9-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: subjects; Type: TABLE; Schema: public; Owner: vietnam_laws
--
DROP TABLE IF EXISTS public.subjects;

CREATE TABLE public.subjects (
    id integer NOT NULL,
    name character varying NOT NULL,
    topic_id integer NOT NULL
);


ALTER TABLE public.subjects OWNER TO vietnam_laws;

--
-- Name: subjects_id_seq; Type: SEQUENCE; Schema: public; Owner: vietnam_laws
--

CREATE SEQUENCE public.subjects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subjects_id_seq OWNER TO vietnam_laws;

--
-- Name: subjects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vietnam_laws
--

ALTER SEQUENCE public.subjects_id_seq OWNED BY public.subjects.id;


--
-- Name: subjects id; Type: DEFAULT; Schema: public; Owner: vietnam_laws
--

ALTER TABLE ONLY public.subjects ALTER COLUMN id SET DEFAULT nextval('public.subjects_id_seq'::regclass);


--
-- Data for Name: subjects; Type: TABLE DATA; Schema: public; Owner: vietnam_laws
--

COPY public.subjects (id, name, topic_id) FROM stdin;
1	An ninh quốc gia	1
2	Bảo vệ bí mật nhà nước	1
3	Bảo vệ công trình quan trọng liên quan đến an ninh quốc gia	1
4	Biên giới quốc gia	1
5	Biển Việt Nam	1
6	Công an nhân dân	1
7	Cơ yếu	1
8	Nhập cảnh, xuất cảnh, quá cảnh, cư trú của người nước ngoài tại Việt Nam	1
9	Phòng, chống khủng bố	1
10	An ninh mạng	1
11	Cảnh vệ	1
12	Bảo hiểm xã hội	2
13	Bảo hiểm y tế	2
14	An toàn thông tin mạng	3
15	Bưu chính	3
16	Công nghệ thông tin	3
17	Giao dịch điện tử	3
18	Tần số vô tuyến điện	3
19	Viễn thông	3
20	Đấu giá tài sản	4
21	Công chứng	4
22	Giám định tư pháp	4
23	Luật sư	4
24	Trợ giúp pháp lý	4
25	Tư vấn pháp luật	4
26	Viên chức	5
27	Chính sách trợ giúp xã hội đối với đối tượng bảo trợ xã hội	6
28	Người cao tuổi	6
29	Người khuyết tật	6
30	Phòng, chống mại dâm	6
31	Điện lực	7
32	Hóa chất	7
33	Khuyến công	7
34	Sử dụng năng lượng tiết kiệm và hiệu quả	7
35	Trẻ em	8
36	Bình đẳng giới	8
37	Dân số	8
38	Hôn nhân và gia đình	8
39	Phòng, chống bạo lực gia đình	8
40	Dân sự	9
41	Quy định thi hành Bộ luật Dân sự về bảo đảm thực hiện nghĩa vụ	9
42	Công tác dân tộc	10
43	Đất đai	11
44	Doanh nghiệp	12
45	Hợp tác xã	12
46	Tổ hợp tác	12
47	Giáo dục	13
48	Giáo dục đại học	13
49	Đường sắt	14
50	Giao thông đường bộ	14
51	Giao thông đường thủy nội địa	14
52	Hàng hải Việt Nam	14
53	Hàng không dân dụng Việt Nam	14
54	Cấp bản sao từ sổ gốc, chứng thực bản sao từ bản chính, chứng thực chữ ký	15
55	Hộ tịch	15
56	Lý lịch tư pháp	15
57	Nuôi con nuôi	15
58	Quốc tịch Việt Nam	15
59	Hình sự	16
60	Kế toán	17
61	Kiểm toán Nhà nước	17
62	Khiếu nại	18
63	Phòng, chống tham nhũng	18
64	Tiếp công dân	18
65	Tố cáo	18
66	Chất lượng sản phẩm, hàng hóa	19
67	Chuyển giao công nghệ	19
68	Công nghệ cao	19
69	Đo lường	19
70	Khoa học và công nghệ	19
71	Năng lượng nguyên tử	19
72	Tiêu chuẩn và quy chuẩn kỹ thuật	19
73	Giáo dục nghề nghiệp	20
74	Lao động	20
75	Việc làm	20
76	An toàn, vệ sinh lao động	20
77	Đa dạng sinh học	21
78	Bảo hiểm tiền gửi	22
79	Các công cụ chuyển nhượng	22
80	Các tổ chức tín dụng	22
81	Ngân hàng Nhà nước Việt Nam	22
82	Ngoại hối	22
83	Cơ quan đại diện nước Cộng hòa Xã hội Chủ nghĩa Việt Nam ở nước ngoài	23
84	Dịch Quốc hiệu, tên các cơ quan, đơn vị và chức danh lãnh đạo, cán bộ công chức trong hệ thống hành chính nhà nước sang tiếng Anh để giao dịch đối ngoại	23
85	Điều ước quốc tế	23
86	Hàm, cấp ngoại giao	23
87	Thỏa thuận quốc tế	23
88	Lập và hoạt động của văn phòng đại diện của các tổ chức hợp tác, nghiên cứu của nước ngoài tại Việt Nam	23
89	Một số chính sách đối với người Việt Nam ở nước ngoài	23
90	Quyền ưu đãi, miễn trừ dành cho cơ quan đại diện ngoại giao, cơ quan lãnh sự và cơ quan đại diện của tổ chức quốc tế tại Việt Nam	23
91	Bảo vệ và kiểm dịch thực vật	24
92	Lâm nghiệp	24
93	Đê điều	24
94	Trồng trọt	24
95	Chăn nuôi	24
96	Thủy lợi	24
97	Quản lý sản xuất, kinh doanh muối	24
98	Phát triển ngành nghề nông thôn	24
99	Thú y	24
100	Thủy sản	24
101	Bảo vệ công trình quốc phòng và khu quân sự	25
102	Biên phòng Việt Nam	25
103	Công nghiệp quốc phòng	25
104	Dân quân tự vệ	25
105	Động viên công nghiệp	25
106	Giáo dục quốc phòng và an ninh	25
107	Cảnh sát biển Việt Nam	25
108	Lực lượng dự bị động viên	25
109	Một số chế độ đối với đối tượng tham gia chiến tranh bảo vệ Tổ quốc, làm nhiệm vụ quốc tế ở Căm-pu-chia, giúp bạn Lào sau ngày 30 tháng 4 năm 1975 có từ đủ 20 năm trở lên phục vụ trong quân đội, công an đã phục viên, xuất ngũ, thôi việc	25
110	Nghĩa vụ quân sự	25
111	Quân nhân chuyên nghiệp, công nhân và viên chức quốc phòng	25
112	Quốc phòng	25
113	Sĩ quan Quân đội nhân dân Việt Nam	25
114	Thực hiện chế độ hưu trí đối với quân nhân trực tiếp tham gia kháng chiến chống Mỹ cứu nước từ ngày 30 tháng 4 năm 1975 trở về trước có 20 năm trở lên phục vụ quân đội đã phục viên, xuất ngũ	25
115	Giá	26
116	Hải quan	26
117	Ngân sách nhà nước	26
118	Đo đạc và bản đồ	27
119	Khí tượng thủy văn	27
120	Khoáng sản	27
121	Tài nguyên, môi trường biển và hải đảo	27
122	Tài nguyên nước	27
123	Hoạt động viễn thám	27
124	Dự trữ quốc gia	28
125	Quản lý, sử dụng tài sản công	28
126	Quản lý và sử dụng viện trợ không hoàn lại không thuộc hỗ trợ phát triển chính thức của các cơ quản, tổ chức, cá nhân nước ngoài dành cho Việt Nam	28
127	Quản lý, sử dụng vốn nhà nước đầu tư vào sản xuất, kinh doanh tại doanh nghiệp	28
128	Thi đua, khen thưởng	29
129	Thi hành án dân sự	30
130	Tổ chức và hoạt động của Thừa phát lại	30
131	Thống kê	31
132	Báo chí	32
133	Tiếp cận thông tin	32
134	Xuất bản	32
135	Chi phí giám định, định giá; chi phí cho người làm chứng, người phiên dịch trong tố tụng	33
136	Phí và lệ phí	33
137	Quản lý thuế	33
138	Thuế giá trị gia tăng	33
139	Thuế sử dụng đất nông nghiệp	33
140	Thuế sử dụng đất phi nông nghiệp	33
141	Thuế tài nguyên	33
142	Thuế thu nhập doanh nghiệp	33
143	Thuế xuất khẩu, thuế nhập khẩu	33
144	Bảo vệ quyền lợi người tiêu dùng	34
145	Cạnh tranh	34
146	Quản lý ngoại thương	34
147	Chứng khoán	34
148	Đầu tư công	34
149	Một số hoạt động kinh doanh đặc thù	34
150	Quản lý thị trường	34
151	Thương mại	34
152	Bầu cử đại biểu Quốc hội và đại biểu Hội đồng nhân dân	35
153	Hoạt động giám sát của Quốc hội và Hội đồng nhân dân	35
154	Mặt trận Tổ quốc Việt Nam	35
155	Thủ đô	35
156	Tổ chức Chính phủ	35
157	Tổ chức chính quyền địa phương	35
158	Tổ chức Quốc hội	35
159	Tổ chức Tòa án nhân dân	35
160	Tổ chức Viện kiểm sát nhân dân	35
161	Công đoàn	36
162	Hoạt động chữ thập đỏ	36
163	Thanh niên	36
164	Tổ chức, hoạt động của quỹ xã hội, quỹ từ thiện	36
165	Quyền lập hội và tổ chức, hoạt động, quản lý hội	36
166	Cựu chiến binh	36
167	Hòa giải ở cơ sở	37
168	Phá sản	37
169	Thủ tục bắt giữ tàu bay	37
170	Thủ tục bắt giữ tàu biển	37
171	Tố tụng dân sự	37
172	Tố tụng hành chính	37
173	Tố tụng hình sự	37
174	Trách nhiệm bồi thường của Nhà nước	37
175	Trọng tài thương mại	37
176	Thi hành tạm giữ, tạm giam	37
177	Tổ chức cơ quan điều tra hình sự	37
178	Hòa giải, đối thoại tại Tòa án	37
179	Tín ngưỡng, tôn giáo	38
180	Chứng minh nhân dân	39
181	Công an xã	39
182	Cư trú	39
183	Điều kiện về an ninh, trật tự đối với một số ngành, nghề kinh doanh có điều kiện	39
184	Một số biện pháp bảo đảm trật tự công cộng	39
185	Phòng cháy và chữa cháy	39
186	Phòng, chống ma túy	39
187	Phòng, chống mua bán người	39
188	Cảnh sát môi trường	39
189	Quản lý, sử dụng pháo	39
190	Quản lý, sử dụng vũ khí, vật liệu nổ và công cụ hỗ trợ	39
191	Quản lý và sử dụng con dấu	39
192	Xử lý vi phạm hành chính	39
193	Cảnh sát cơ động	39
194	Căn cước công dân	39
195	Tương trợ tư pháp	40
196	Hoạt động nghệ thuật biểu diễn	41
197	Nhuận bút, thù lao đối với tác phẩm điện ảnh, mỹ thuật, nhiếp ảnh, sân khấu và các loại hình nghệ thuật biểu diễn khác	41
198	Di sản văn hóa	41
199	Du lịch	41
200	Hoạt động mỹ thuật	41
201	Hoạt động văn hóa và kinh doanh dịch vụ văn hóa công cộng	41
202	Quảng cáo	41
203	Quy chế đặt tên, đổi tên đường, phố và công trình công cộng	41
204	Thể dục, thể thao	41
205	Thư viện	41
206	Thực hiện nếp sống văn minh trong việc cưới, việc tang	41
207	Tổ chức lễ tang cán bộ, công chức, viên chức	41
208	Công tác văn thư	42
209	Lưu trữ	42
210	Kiến trúc	43
211	Kinh doanh bất động sản	43
212	Ban hành văn bản quy phạm pháp luật	44
213	Chức năng, nhiệm vụ, quyền hạn và tổ chức bộ máy của tổ chức pháp chế	44
214	Hợp nhất văn bản quy phạm pháp luật	44
215	Kiểm soát thủ tục hành chính	44
216	Pháp điển hệ thống quy phạm pháp luật	44
217	Phổ biến, giáo dục pháp luật	44
218	Quản lý hợp tác quốc tế về pháp luật	44
219	Theo dõi tình hình thi hành pháp luật	44
220	Tiếp nhận, xử lý phản ánh, kiến nghị của cá nhân, tổ chức về quy định hành chính	44
221	Trưng cầu ý dân	44
222	An toàn thực phẩm	45
223	Bảo vệ sức khỏe nhân dân	45
224	Cơ chế hoạt động, cơ chế tài chính đối với các đơn vị sự nghiệp y tế công lập và giá dịch vụ khám bệnh, chữa bệnh của các cơ sở khám bệnh, chữa bệnh công lập	45
225	Dược	45
226	Hiến, lấy, ghép mô, bộ phận cơ thể người và hiến, lấy xác	45
227	Khám bệnh, chữa bệnh	45
228	Phòng, chống bệnh truyền nhiễm	45
229	Phòng, chống nhiễm vi rút gây ra hội chứng suy giảm miễn dịch mắc phải ở người	45
230	Phòng, chống tác hại của thuốc lá	45
231	Điều kiện sản xuất mỹ phẩm	45
232	Phòng, chống tác hại của rượu, bia	45
233	Quản lý trang thiết bị y tế	45
\.


--
-- Name: subjects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vietnam_laws
--

SELECT pg_catalog.setval('public.subjects_id_seq', 233, true);


--
-- Name: subjects PK_1a023685ac2b051b4e557b0b280; Type: CONSTRAINT; Schema: public; Owner: vietnam_laws
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT "PK_1a023685ac2b051b4e557b0b280" PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

