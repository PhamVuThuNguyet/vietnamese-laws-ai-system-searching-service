--
-- PostgreSQL database dump
--

-- Dumped from database version 14.10 (Debian 14.10-1.pgdg120+1)
-- Dumped by pg_dump version 14.9 (Ubuntu 14.9-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: topics; Type: TABLE; Schema: public; Owner: vietnam_laws
--

DROP TABLE IF EXISTS public.topics;

CREATE TABLE public.topics (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.topics OWNER TO vietnam_laws;

--
-- Name: topics_id_seq; Type: SEQUENCE; Schema: public; Owner: vietnam_laws
--

CREATE SEQUENCE public.topics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.topics_id_seq OWNER TO vietnam_laws;

--
-- Name: topics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vietnam_laws
--

ALTER SEQUENCE public.topics_id_seq OWNED BY public.topics.id;


--
-- Name: topics id; Type: DEFAULT; Schema: public; Owner: vietnam_laws
--

ALTER TABLE ONLY public.topics ALTER COLUMN id SET DEFAULT nextval('public.topics_id_seq'::regclass);


--
-- Data for Name: topics; Type: TABLE DATA; Schema: public; Owner: vietnam_laws
--

COPY public.topics (id, name) FROM stdin;
1	An ninh quốc gia
2	Bảo hiểm
3	Bưu chính, viễn thông
4	Bổ trợ tư pháp
5	Cán bộ, công chức, viên chức
6	Chính sách xã hội
7	Công nghiệp
8	Dân số, gia đình, trẻ em, bình đẳng giới
9	Dân sự
10	Dân tộc
11	Đất đai
12	Doanh nghiệp, hợp tác xã
13	Giáo dục, đào tạo
14	Giao thông, vận tải
15	Hành chính tư pháp
16	Hình sự
17	Kế toán, kiểm toán
18	Khiếu nại, tố cáo
19	Khoa học, công nghệ
20	Lao động
21	Môi trường
22	Ngân hàng, tiền tệ
23	Ngoại giao, điều ước quốc tế
24	Nông nghiệp, nông thôn
25	Quốc phòng
26	Tài chính
27	Tài nguyên
28	Tài sản công, nợ công, dự trữ nhà nước
29	Thi đua, khen thưởng, các danh hiệu vinh dự nhà nước
30	Thi hành án
31	Thống kê
32	Thông tin, báo chí, xuất bản
33	Thuế, phí, lệ phí, các khoản thu khác
34	Thương mại, đầu tư, chứng khoán
35	Tổ chức bộ máy nhà nước
36	Tổ chức chính trị - xã hội, hội
37	Tố tụng và các phương thức giải quyết tranh chấp
38	Tôn giáo, tín ngưỡng
39	Trật tự, an toàn xã hội
40	Tương trợ tư pháp
41	Văn hóa, thể thao, du lịch
42	Văn thư lưu trữ
43	Xây dựng, nhà ở, đô thị
44	Xây dựng pháp luật và thi hành pháp luật
45	Y tế, dược
\.


--
-- Name: topics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vietnam_laws
--

SELECT pg_catalog.setval('public.topics_id_seq', 45, true);


--
-- Name: topics PK_e4aa99a3fa60ec3a37d1fc4e853; Type: CONSTRAINT; Schema: public; Owner: vietnam_laws
--

ALTER TABLE ONLY public.topics
    ADD CONSTRAINT "PK_e4aa99a3fa60ec3a37d1fc4e853" PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

